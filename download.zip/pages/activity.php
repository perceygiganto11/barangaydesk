<div class="section-head"><div><div class="eyebrow">AUDIT TRAIL</div><h3>Recent activity</h3></div></div>
<div class="list-card">
<?php if (!$activities): ?>
    <div class="empty">No activity recorded yet.</div>
<?php else: foreach ($activities as $activity): ?>
    <div class="activity"><span class="timeline-dot"></span><div><strong><?= e($activity['action']) ?></strong><small><?= e($activity['module']) ?> · <?= e(date('M j, Y · g:i A', strtotime($activity['timestamp']))) ?></small></div></div>
<?php endforeach; endif; ?>
</div>
