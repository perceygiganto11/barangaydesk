<div class="section-head"><div><div class="eyebrow">SERVICES</div><h3>What do you need today?</h3></div></div>
<div class="catalog-grid">
<?php foreach ($documents as $document): ?>
    <article class="doc-card">
        <div class="doc-icon">▧</div>
        <h3><?= e($document['document_name']) ?></h3>
        <p><?= e($document['description']) ?></p>
        <div class="doc-meta"><span>₱<?= number_format((float) $document['fee'], 2) ?></span><span><?= e((string) $document['processing_days']) ?> days</span></div>
        <details><summary>View requirements</summary><p><?= e($document['requirements']) ?></p></details>
        <form method="post" class="request-form">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="create_request">
            <input type="hidden" name="document_id" value="<?= $document['document_id'] ?>">
            <label>Purpose<textarea name="purpose" required placeholder="Tell us why you need this document"></textarea></label>
            <button class="button" type="submit">Submit request</button>
        </form>
    </article>
<?php endforeach; ?>
</div>
