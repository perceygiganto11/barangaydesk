<div class="section-head">
    <div><div class="eyebrow">TRACKING</div><h3><?= is_staff() ? 'All incoming requests' : 'Your submitted requests' ?></h3></div>
    <a class="button" href="index.php?view=catalog">+ New request</a>
</div>
<form method="get" class="search-form">
    <input type="hidden" name="view" value="requests">
    <label class="sr-only" for="request-search">Search requests</label>
    <input id="request-search" type="search" name="q" value="<?= e((string) ($_GET['q'] ?? '')) ?>" placeholder="Search by purpose, status, document, or resident">
    <button class="button secondary" type="submit">Search requests</button>
    <?php if (!empty($_GET['q'])): ?><a class="text-link" href="index.php?view=requests">Clear search</a><?php endif; ?>
</form>
<?php include __DIR__ . '/../components/request_table.php'; ?>
