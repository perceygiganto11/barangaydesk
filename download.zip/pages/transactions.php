<div class="section-head">
    <div><div class="eyebrow">TCL DEMO · PAYMENTS</div><h3><?= is_staff() ? 'All fee payments' : 'Your fee payments' ?></h3></div>
</div>

<p class="sub">Same idea as the transaction demo: one payment inserts into <code>transactions</code>, moves the request to <em>reviewing</em>, and creates a notification — all inside a single <code>BEGIN … COMMIT / ROLLBACK</code> block in <code>classes/Transaction.php</code>. If any step fails (wrong request, kulang nga bayad, doble nga bayad), walay ma-save.</p>

<div class="table-card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>TRANSACT</th><?php if (is_staff()): ?><th>RESIDENT</th><?php endif; ?><th>REQUEST</th><th>AMOUNT (₱)</th><th>METHOD</th><th>DATE</th></tr></thead>
            <tbody>
            <?php if (!$transactions): ?>
                <tr><td colspan="6"><div class="empty">No payments yet. Pay for an unpaid request below.</div></td></tr>
            <?php else: foreach ($transactions as $t): ?>
                <tr>
                    <td><strong>#<?= str_pad((string) $t['transact_id'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                    <?php if (is_staff()): ?><td><?= e($t['full_name']) ?></td><?php endif; ?>
                    <td><strong>#<?= str_pad((string) $t['request_id'], 4, '0', STR_PAD_LEFT) ?></strong><small><?= e($t['document_name']) ?> · <?= e(ucfirst($t['request_status'])) ?></small></td>
                    <td>₱<?= number_format((float) $t['amount_paid'], 2) ?></td>
                    <td><?= e(ucfirst($t['payment_method'])) ?></td>
                    <td><?= e(date('M j, Y g:i A', strtotime($t['payment_date']))) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="section-head" style="margin-top:22px">
    <div><div class="eyebrow">PAY FEE</div><h3>Pay for a request</h3></div>
</div>

<?php if (!$unpaid): ?>
    <div class="table-card"><div class="empty">All requests are paid. 🎉</div></div>
<?php else: ?>
<div class="table-card">
    <form method="post" class="request-form" style="padding:18px">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="pay_fee">
        <label>Request
            <select name="request_id" id="pay-request" required>
                <?php foreach ($unpaid as $u): ?>
                    <option value="<?= $u['request_id'] ?>" data-fee="<?= e((string) $u['fee']) ?>">
                        #<?= str_pad((string) $u['request_id'], 4, '0', STR_PAD_LEFT) ?> — <?= e($u['document_name']) ?> (₱<?= number_format((float) $u['fee'], 2) ?>)<?php if (is_staff()): ?> — <?= e($u['full_name']) ?><?php endif; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <label>Amount (₱)<input type="number" name="amount" id="pay-amount" step="0.01" min="0" placeholder="0.00" required></label>
            <label>Payment method
                <select name="payment_method" required>
                    <option value="cash">Cash</option>
                    <option value="gcash">GCash</option>
                    <option value="maya">Maya</option>
                    <option value="bank">Bank</option>
                </select>
            </label>
        </div>
        <button class="button" type="submit">Pay now</button>
        <small class="sub">Ginamitan ug transaction: BEGIN → INSERT payment → UPDATE request → INSERT notification → COMMIT. Mo-ROLLBACK kung naay sayop.</small>
    </form>
</div>
<script>
// Auto-fill exact fee when request changes (same UX as demo's amount field).
(function () {
    var sel = document.getElementById('pay-request');
    var amt = document.getElementById('pay-amount');
    function sync() { amt.value = sel.options[sel.selectedIndex].getAttribute('data-fee'); }
    sel.addEventListener('change', sync); sync();
})();
</script>
<?php endif; ?>
