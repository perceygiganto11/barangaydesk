<div class="section-head"><div><div class="eyebrow">UPDATES</div><h3>Your notifications</h3></div><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="mark_read"><button class="button secondary">Mark all as read</button></form></div>
<div class="list-card">
<?php if (!$notifications): ?>
    <div class="empty">No notifications yet.</div>
<?php else: foreach ($notifications as $notification): ?>
    <div class="notification <?= !$notification['is_read'] ? 'unread' : '' ?>"><span class="notice-dot"></span><div><strong><?= e($notification['message']) ?></strong><small><?= e(date('M j, Y · g:i A', strtotime($notification['sent_at']))) ?></small></div></div>
<?php endforeach; endif; ?>
</div>
