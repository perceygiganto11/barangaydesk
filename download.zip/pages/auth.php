<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($view === 'register' ? 'Create an account' : 'Sign in') ?> · BarangayDesk</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="auth-shell">
    <div class="auth-panel">
        <a class="brand" href="index.php"><span class="brand-mark">B</span><span>Barangay<span class="muted">Desk</span></span></a>
        <div class="auth-copy">
            <div class="eyebrow accent">LOCAL SERVICES · ONLINE</div>
            <h1><?= $view === 'register' ? 'Make requests simpler.' : 'Your barangay, now within reach.' ?></h1>
            <p>Securely request community documents, upload requirements, and monitor progress from anywhere.</p>
        </div>
        <div class="auth-note">Designed for residents and barangay staff.</div>
    </div>
    <div class="auth-form">
        <div class="form-box">
            <?php foreach ($flashes as [$type, $msg]): ?><div class="alert <?= e($type) ?>"><?= e($msg) ?></div><?php endforeach; ?>
            <?php if ($view === 'register'): ?>
                <div class="eyebrow">NEW ACCOUNT</div><h2>Create your account</h2><p class="sub">Use your real information to get started.</p>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="register">
                    <label>Full name<input name="full_name" required></label><label>Email address<input type="email" name="email" required></label><label>Contact number<input name="contact_number" required></label><label>Address<input name="address" required></label><label>Password<input type="password" name="password" minlength="8" required></label>
                    <button class="button full">Create account</button>
                </form>
                <p class="switch">Already registered? <a href="index.php?view=login">Sign in</a></p>
            <?php else: ?>
                <div class="eyebrow">WELCOME BACK</div><h2>Sign in to BarangayDesk</h2><p class="sub">Access your requests and updates.</p>
                <form method="post">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="login">
                    <label>Email address<input type="email" name="email" required autocomplete="email"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label>
                    <button class="button full">Sign in</button>
                </form>
                <p class="switch">New here? <a href="index.php?view=register">Create an account</a></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
