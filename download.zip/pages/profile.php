<div class="profile-card">
    <div class="profile-avatar"><?= e(strtoupper(substr($current['full_name'], 0, 1))) ?></div>
    <h2><?= e($current['full_name']) ?></h2>
    <p><?= e($current['email']) ?></p>
    <div class="profile-fields">
        <div><span>ACCOUNT TYPE</span><strong><?= e(ucfirst($current['user_type'])) ?></strong></div>
        <div><span>CONTACT NUMBER</span><strong><?= e($current['contact_number']) ?></strong></div>
        <div><span>ADDRESS</span><strong><?= e($current['address']) ?></strong></div>
    </div>
</div>
