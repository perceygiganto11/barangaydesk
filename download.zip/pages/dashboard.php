<?php
$inProgress = count(array_filter($requests, static fn (array $request): bool => in_array($request['status'], ['pending', 'reviewing'], true)));
?>
<div class="hero">
    <div>
        <div class="eyebrow accent">LOCAL SERVICES · ONLINE</div>
        <h2>Request documents without the queue.</h2>
        <p>Submit requirements, follow progress, and get notified when your barangay document is ready.</p>
        <a class="button light" href="index.php?view=catalog">Browse documents →</a>
    </div>
    <div class="hero-art">◈<span>⌁</span>◉</div>
</div>
<div class="stat-grid">
    <div class="stat"><span>MY REQUESTS</span><strong><?= count($requests) ?></strong><small>All submitted requests</small></div>
    <div class="stat"><span>IN PROGRESS</span><strong><?= $inProgress ?></strong><small>Awaiting completion</small></div>
    <div class="stat"><span>AVAILABLE DOCS</span><strong><?= count($documents) ?></strong><small>Services in the catalog</small></div>
</div>
<div class="section-head">
    <div><div class="eyebrow">RECENT ACTIVITY</div><h3>Keep track of your requests</h3></div>
    <a class="text-link" href="index.php?view=requests">View all →</a>
</div>
<?php include __DIR__ . '/../components/request_table.php'; ?>
