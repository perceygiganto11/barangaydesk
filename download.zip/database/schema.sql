CREATE DATABASE IF NOT EXISTS barangay_document_requests CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE barangay_document_requests;

CREATE TABLE users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_type ENUM('resident','staff','admin') NOT NULL DEFAULT 'resident',
    full_name VARCHAR(150) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    address VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE document_types (
    document_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    document_name VARCHAR(150) NOT NULL UNIQUE,
    description VARCHAR(255) NOT NULL,
    requirements TEXT NOT NULL,
    fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    processing_days INT UNSIGNED NOT NULL DEFAULT 3
) ENGINE=InnoDB;

CREATE TABLE requests (
    request_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    purpose VARCHAR(255) NOT NULL,
    status ENUM('pending','reviewing','approved','rejected','released') NOT NULL DEFAULT 'pending',
    submission_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estimated_completion DATETIME NULL,
    document_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    staff_id INT UNSIGNED NULL,
    notes TEXT NULL,
    CONSTRAINT fk_requests_document FOREIGN KEY (document_id) REFERENCES document_types(document_id),
    CONSTRAINT fk_requests_user FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT fk_requests_staff FOREIGN KEY (staff_id) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE uploaded_files (
    file_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    validation_result ENUM('pending','valid','invalid') NOT NULL DEFAULT 'pending',
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    request_id INT UNSIGNED NOT NULL,
    CONSTRAINT fk_files_request FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE transactions (
    transact_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    amount_paid DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method VARCHAR(50) NOT NULL,
    payment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    request_id INT UNSIGNED NOT NULL UNIQUE,
    CONSTRAINT fk_transactions_request FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
    notif_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    message VARCHAR(500) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    request_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NOT NULL,
    CONSTRAINT fk_notifications_request FOREIGN KEY (request_id) REFERENCES requests(request_id) ON DELETE SET NULL,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
    log_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    action VARCHAR(255) NOT NULL,
    module VARCHAR(100) NOT NULL,
    timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INT UNSIGNED NOT NULL,
    CONSTRAINT fk_logs_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO document_types (document_name, description, requirements, fee, processing_days) VALUES
('Barangay Clearance','Proof of good standing in the barangay','Valid ID; proof of residence',50.00,3),
('Certificate of Residency','Certification of current residence','Valid ID; utility bill or lease contract',50.00,3),
('Certificate of Indigency','Certification for qualified assistance programs','Valid ID; social worker assessment',0.00,5),
('Business Clearance','Clearance for businesses operating in the barangay','Business permit; valid ID; lease contract',100.00,5);
