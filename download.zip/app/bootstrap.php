<?php

session_start();
require_once dirname(__DIR__) . '/connection.php';
require_once dirname(__DIR__) . '/classes/Request.php';
require_once dirname(__DIR__) . '/classes/Transaction.php';

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect(string $url = 'index.php'): never { header('Location: ' . $url); exit; }
function flash(string $type, string $message): void { $_SESSION['flash'][] = [$type, $message]; }
function take_flash(): array { $items = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $items; }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(24)); }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid form token. Please go back and try again.'); } }
function user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): array { $u = user(); if (!$u) redirect('index.php?view=login'); return $u; }
function is_staff(): bool { return in_array(user()['user_type'] ?? '', ['staff', 'admin'], true); }
function log_activity(int $userId, string $action, string $module): void { $s = db()->prepare('INSERT INTO activity_logs (action,module,user_id) VALUES (?,?,?)'); $s->execute([$action, $module, $userId]); }
function notify(int $userId, ?int $requestId, string $message): void { $s = db()->prepare('INSERT INTO notifications (user_id,request_id,message) VALUES (?,?,?)'); $s->execute([$userId, $requestId, $message]); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'register') {
            $name = trim($_POST['full_name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? ''));
            $password = $_POST['password'] ?? ''; $contact = trim($_POST['contact_number'] ?? ''); $address = trim($_POST['address'] ?? '');
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || $contact === '' || $address === '') throw new RuntimeException('Please complete all fields. Passwords must contain at least 8 characters.');
            $s = db()->prepare('INSERT INTO users (full_name,contact_number,email,address,password_hash) VALUES (?,?,?,?,?)');
            $s->execute([$name, $contact, $email, $address, password_hash($password, PASSWORD_DEFAULT)]);
            flash('success', 'Registration complete. You can now sign in.'); redirect('index.php?view=login');
        }
        if ($action === 'login') {
            $s = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1'); $s->execute([strtolower(trim($_POST['email'] ?? ''))]); $found = $s->fetch();
            if (!$found || !password_verify($_POST['password'] ?? '', $found['password_hash'])) throw new RuntimeException('The email or password is incorrect.');
            session_regenerate_id(true); unset($found['password_hash']); $_SESSION['user'] = $found; log_activity((int)$found['user_id'], 'Signed in', 'Authentication'); redirect('index.php');
        }
        if ($action === 'logout') { session_destroy(); redirect('index.php?view=login'); }
        $current = require_login();
        if ($action === 'mark_read') { db()->prepare('UPDATE notifications SET is_read=1 WHERE user_id=?')->execute([$current['user_id']]); flash('success', 'Notifications marked as read.'); redirect('index.php?view=notifications'); }
        if ($action === 'create_request') {
            $doc = (int)($_POST['document_id'] ?? 0); $purpose = trim($_POST['purpose'] ?? '');
            if (!$doc || $purpose === '') throw new RuntimeException('Choose a document type and provide the purpose of your request.');
            $s = db()->prepare('SELECT * FROM document_types WHERE document_id=?'); $s->execute([$doc]); $type = $s->fetch(); if (!$type) throw new RuntimeException('The selected document type is unavailable.');
            $complete = date('Y-m-d H:i:s', strtotime('+' . (int) $type['processing_days'] . ' days'));
            $requestEntity = new Request(db());
            $rid = $requestEntity->addRequest($purpose, $doc, (int) $current['user_id'], $complete);
            log_activity((int)$current['user_id'], 'Submitted document request #' . $rid, 'Requests'); flash('success', 'Your request has been submitted.'); redirect('index.php?view=requests');
        }
        if ($action === 'update_status' && is_staff()) {
            $rid = (int) $_POST['request_id']; $status = $_POST['status'] ?? 'pending'; $allowed = ['pending','reviewing','approved','rejected','released']; if (!in_array($status, $allowed, true)) throw new RuntimeException('Invalid status.');
            $requestEntity = new Request(db());
            $request = $requestEntity->getRequest($rid); if (!$request) throw new RuntimeException('Request not found.');
            $requestEntity->updateRequest($rid, ['status' => $status, 'staff_id' => (int) $current['user_id']]); notify((int) $request['user_id'], $rid, 'Request #' . $rid . ' status updated to ' . ucfirst($status) . '.'); log_activity((int) $current['user_id'], 'Updated request #' . $rid . ' to ' . $status, 'Requests'); flash('success', 'Request status updated.'); redirect('index.php?view=requests');
        }
        if ($action === 'update_request') {
            $rid = (int) ($_POST['request_id'] ?? 0);
            $purpose = trim((string) ($_POST['purpose'] ?? ''));
            $requestEntity = new Request(db());
            $request = $requestEntity->getRequest($rid);
            if (!$request || (!is_staff() && (int) $request['user_id'] !== (int) $current['user_id'])) throw new RuntimeException('Request not found.');
            if ($purpose === '') throw new RuntimeException('The request purpose cannot be empty.');
            $requestEntity->updateRequest($rid, ['purpose' => $purpose]);
            log_activity((int) $current['user_id'], 'Updated request #' . $rid, 'Requests');
            flash('success', 'Request updated.');
            redirect('index.php?view=requests');
        }
        if ($action === 'delete_request') {
            $rid = (int) ($_POST['request_id'] ?? 0);
            $requestEntity = new Request(db());
            $request = $requestEntity->getRequest($rid);
            if (!$request || (!is_staff() && (int) $request['user_id'] !== (int) $current['user_id'])) throw new RuntimeException('Request not found.');
            if (!$requestEntity->deleteRequest($rid)) throw new RuntimeException('Request not found.');
            log_activity((int) $current['user_id'], 'Deleted request #' . $rid, 'Requests');
            flash('success', 'Request deleted.');
            redirect('index.php?view=requests');
        }
        if ($action === 'upload_file') {
            $rid = (int) $_POST['request_id']; $requestEntity = new Request(db()); $request = $requestEntity->getRequest($rid); if (!$request || (int) $request['user_id'] !== (int) $current['user_id']) throw new RuntimeException('Request not found.');
            if (empty($_FILES['document']['name']) || $_FILES['document']['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Choose a file to upload.');
            $ext = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION)); if (!in_array($ext, ['pdf','jpg','jpeg','png'], true) || $_FILES['document']['size'] > 5*1024*1024) throw new RuntimeException('Upload a PDF, JPG, or PNG file up to 5 MB.');
            $dir = __DIR__ . '/../uploads'; if (!is_dir($dir)) mkdir($dir, 0750, true); $stored = bin2hex(random_bytes(12)) . '.' . $ext; move_uploaded_file($_FILES['document']['tmp_name'], $dir . '/' . $stored);
            db()->prepare('INSERT INTO uploaded_files (file_name,file_path,validation_result,request_id) VALUES (?,?,"pending",?)')->execute([$_FILES['document']['name'], 'uploads/' . $stored, $rid]); flash('success', 'File uploaded for review.'); redirect('index.php?view=requests');
        }
        if ($action === 'pay_fee') {
            $rid = (int) ($_POST['request_id'] ?? 0);
            $amount = (float) ($_POST['amount'] ?? 0);
            $method = (string) ($_POST['payment_method'] ?? 'cash');
            $transaction = new Transaction(db());
            $result = $transaction->payForRequest($rid, $amount, $method, (int) $current['user_id'], is_staff());
            if ($result['status'] !== 'success') throw new RuntimeException($result['message']);
            log_activity((int) $current['user_id'], 'Recorded payment for request #' . $rid, 'Payments');
            flash('success', $result['message']); redirect('index.php?view=transactions');
        }
    } catch (Throwable $ex) {
        $message = $ex->getMessage();
        if ($ex instanceof PDOException && $ex->getCode() === '23000') $message = 'That email address is already registered. Try signing in instead.';
        flash('danger', $message ?: 'Something went wrong. Please try again.'); redirect('index.php' . (user() ? '' : '?view=login'));
    }
}
