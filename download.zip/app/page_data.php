<?php

function page_title(string $view): string
{
    return match ($view) {
        'catalog' => 'Document Catalog',
        'requests' => 'Document Requests',
        'transactions' => 'Payments & Transactions',
        'notifications' => 'Notifications',
        'activity' => 'Activity History',
        'profile' => 'My Profile',
        default => 'Dashboard',
    };
}

function load_page_data(?array $current, string $view): array
{
    $data = [
        'documents' => [],
        'requests' => [],
        'transactions' => [],
        'unpaid' => [],
        'notifications' => [],
        'activities' => [],
    ];

    if (!$current) {
        return $data;
    }

    $pdo = db();
    $data['documents'] = $pdo->query('SELECT * FROM document_types ORDER BY document_name')->fetchAll();
    $requestEntity = new Request($pdo);
    $keyword = trim((string) ($_GET['q'] ?? ''));
    $data['requests'] = $keyword !== ''
        ? $requestEntity->searchRequests($keyword, (int) $current['user_id'], is_staff())
        : $requestEntity->getRequests((int) $current['user_id'], is_staff());

    $transactionEntity = new Transaction($pdo);
    $data['transactions'] = $transactionEntity->getPayments((int) $current['user_id'], is_staff());
    $data['unpaid'] = $transactionEntity->getUnpaidRequests((int) $current['user_id'], is_staff());

    if ($view === 'notifications') {
        $statement = $pdo->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY sent_at DESC');
        $statement->execute([$current['user_id']]);
        $data['notifications'] = $statement->fetchAll();
    }

    if ($view === 'activity') {
        $statement = $pdo->prepare('SELECT * FROM activity_logs WHERE user_id=? ORDER BY timestamp DESC LIMIT 50');
        $statement->execute([$current['user_id']]);
        $data['activities'] = $statement->fetchAll();
    }

    return $data;
}
