<?php

require_once __DIR__ . '/request_operations/AddRequest.php';
require_once __DIR__ . '/request_operations/GetRequests.php';
require_once __DIR__ . '/request_operations/UpdateRequest.php';
require_once __DIR__ . '/request_operations/DeleteRequest.php';
require_once __DIR__ . '/request_operations/SearchRequests.php';

final class Request
{
    public function __construct(private PDO $pdo)
    {
    }

    public function addRequest(string $purpose, int $documentId, int $userId, ?string $estimatedCompletion = null, string $status = 'pending', ?int $staffId = null, ?string $notes = null): int
    {
        return addRequestRecord($this->pdo, $purpose, $documentId, $userId, $estimatedCompletion, $status, $staffId, $notes);
    }

    public function getRequests(?int $userId = null, bool $staffView = false): array
    {
        return getRequestRecords($this->pdo, $userId, $staffView);
    }

    public function getRequest(int $id): ?array
    {
        return getRequestRecord($this->pdo, $id);
    }

    public function updateRequest(int $id, array $details = []): bool
    {
        return updateRequestRecord($this->pdo, $id, $details);
    }

    public function deleteRequest(int $id): bool
    {
        return deleteRequestRecord($this->pdo, $id);
    }

    public function searchRequests(string $keyword, ?int $userId = null, bool $staffView = false): array
    {
        return searchRequestRecords($this->pdo, $keyword, $userId, $staffView);
    }
}
