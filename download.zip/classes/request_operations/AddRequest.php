<?php

function addRequestRecord(PDO $pdo, string $purpose, int $documentId, int $userId, ?string $estimatedCompletion = null, string $status = 'pending', ?int $staffId = null, ?string $notes = null): int
{
    $statement = $pdo->prepare(
        'INSERT INTO requests (purpose, status, estimated_completion, document_id, user_id, staff_id, notes)
         VALUES (:purpose, :status, :estimated_completion, :document_id, :user_id, :staff_id, :notes)'
    );
    $statement->execute([
        ':purpose' => $purpose,
        ':status' => $status,
        ':estimated_completion' => $estimatedCompletion,
        ':document_id' => $documentId,
        ':user_id' => $userId,
        ':staff_id' => $staffId,
        ':notes' => $notes,
    ]);

    return (int) $pdo->lastInsertId();
}
