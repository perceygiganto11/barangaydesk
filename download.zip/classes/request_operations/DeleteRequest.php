<?php

function deleteRequestRecord(PDO $pdo, int $id): bool
{
    $statement = $pdo->prepare('DELETE FROM requests WHERE request_id = :request_id');
    $statement->execute([':request_id' => $id]);

    return $statement->rowCount() > 0;
}
