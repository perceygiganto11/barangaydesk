<?php

function updateRequestRecord(PDO $pdo, int $id, array $details = []): bool
{
    $allowed = ['purpose', 'status', 'estimated_completion', 'document_id', 'staff_id', 'notes'];
    $changes = array_intersect_key($details, array_flip($allowed));

    if (!$changes) {
        return false;
    }

    $assignments = [];
    $parameters = [':request_id' => $id];
    foreach ($changes as $field => $value) {
        $assignments[] = "{$field} = :{$field}";
        $parameters[":{$field}"] = $value;
    }

    $statement = $pdo->prepare('UPDATE requests SET ' . implode(', ', $assignments) . ' WHERE request_id = :request_id');
    $statement->execute($parameters);

    return $statement->rowCount() > 0;
}
