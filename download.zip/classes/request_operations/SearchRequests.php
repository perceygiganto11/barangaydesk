<?php

function searchRequestRecords(PDO $pdo, string $keyword, ?int $userId = null, bool $staffView = false): array
{
    $like = '%' . trim($keyword) . '%';
    $sql = 'SELECT r.*, d.document_name, u.full_name
            FROM requests r
            JOIN document_types d ON d.document_id = r.document_id
            JOIN users u ON u.user_id = r.user_id
            WHERE (r.purpose LIKE :purpose OR r.status LIKE :status OR d.document_name LIKE :document_name OR u.full_name LIKE :full_name)';
    $parameters = [
        ':purpose' => $like,
        ':status' => $like,
        ':document_name' => $like,
        ':full_name' => $like,
    ];

    if (!$staffView && $userId !== null) {
        $sql .= ' AND r.user_id = :user_id';
        $parameters[':user_id'] = $userId;
    }

    $sql .= ' ORDER BY r.submission_date DESC';
    $statement = $pdo->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}
