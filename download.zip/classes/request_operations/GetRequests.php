<?php

function getRequestRecords(PDO $pdo, ?int $userId = null, bool $staffView = false): array
{
    $sql = 'SELECT r.*, d.document_name, u.full_name
            FROM requests r
            JOIN document_types d ON d.document_id = r.document_id
            JOIN users u ON u.user_id = r.user_id';
    $parameters = [];

    if (!$staffView && $userId !== null) {
        $sql .= ' WHERE r.user_id = :user_id';
        $parameters[':user_id'] = $userId;
    }

    $sql .= ' ORDER BY r.submission_date DESC';
    $statement = $pdo->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}

function getRequestRecord(PDO $pdo, int $id): ?array
{
    $statement = $pdo->prepare('SELECT * FROM requests WHERE request_id = :request_id LIMIT 1');
    $statement->execute([':request_id' => $id]);
    $request = $statement->fetch();

    return $request ?: null;
}
