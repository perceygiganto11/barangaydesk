<?php

/**
 * Transaction entity for BarangayDesk fee payments.
 *
 * Mirrors the TCL demo from transaction_demo.zip (connection.php +
 * Transaction.php + index.php) but adapted to the barangay workflow:
 * paying the document fee for a request must atomically:
 *   1) insert a row into `transactions`
 *   2) move the request forward (pending -> reviewing)
 *   3) notify the request owner
 *
 * All three writes run inside one PDO transaction so a failure in any
 * step triggers a ROLLBACK and no partial payment is left behind.
 */
final class Transaction
{
    public function __construct(private PDO $pdo)
    {
    }

    /**
     * Pay the fee for a document request. Returns demo-style result array:
     * ["status" => "success"|"error", "message" => string]
     */
    public function payForRequest(int $requestId, float $amount, string $method, int $actorId, bool $isStaff): array
    {
        $allowedMethods = ['cash', 'gcash', 'maya', 'bank'];
        $method = strtolower(trim($method));

        try {
            if ($requestId <= 0) {
                throw new RuntimeException('Choose a valid request to pay for.');
            }
            if ($amount < 0) {
                throw new RuntimeException('Payment amount cannot be negative.');
            }
            if (!in_array($method, $allowedMethods, true)) {
                throw new RuntimeException('Choose a valid payment method.');
            }

            $this->pdo->beginTransaction();

            // Lock the request row so double-payments cannot race.
            $stmt = $this->pdo->prepare(
                'SELECT r.*, d.document_name, d.fee
                 FROM requests r
                 JOIN document_types d ON d.document_id = r.document_id
                 WHERE r.request_id = ? FOR UPDATE'
            );
            $stmt->execute([$requestId]);
            $request = $stmt->fetch();

            if (!$request) {
                throw new RuntimeException("Request #$requestId does not exist.");
            }
            if (!$isStaff && (int) $request['user_id'] !== $actorId) {
                throw new RuntimeException('You can only pay for your own requests.');
            }

            // Already paid? transactions.request_id is UNIQUE.
            $check = $this->pdo->prepare('SELECT COUNT(*) FROM transactions WHERE request_id = ?');
            $check->execute([$requestId]);
            if ((int) $check->fetchColumn() > 0) {
                throw new RuntimeException("Request #$requestId is already paid.");
            }

            $fee = (float) $request['fee'];
            if ($amount < $fee) {
                throw new RuntimeException(
                    'Insufficient payment. The fee for ' . $request['document_name'] .
                    ' is ₱' . number_format($fee, 2) . '.'
                );
            }

            // 1) Record the payment.
            $insert = $this->pdo->prepare(
                'INSERT INTO transactions (amount_paid, payment_method, request_id) VALUES (?,?,?)'
            );
            $insert->execute([$amount, $method, $requestId]);

            // 2) Move the request forward atomically with the payment.
            $update = $this->pdo->prepare(
                "UPDATE requests SET status = 'reviewing', staff_id = COALESCE(staff_id, ?) WHERE request_id = ?"
            );
            $update->execute([$isStaff ? $actorId : null, $requestId]);

            // 3) Notify the owner inside the same transaction.
            $notify = $this->pdo->prepare(
                'INSERT INTO notifications (user_id, request_id, message) VALUES (?,?,?)'
            );
            $notify->execute([
                (int) $request['user_id'],
                $requestId,
                'Payment of ₱' . number_format($amount, 2) . " ($method) received for request #$requestId.",
            ]);

            $this->pdo->commit();

            return [
                'status' => 'success',
                'message' => '₱' . number_format($amount, 2) . " paid successfully for request #$requestId.",
            ];
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }

            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }

    /**
     * Video 2 (Bro Code): check current AUTOCOMMIT mode.
     * MySQL default is 1 — every INSERT/UPDATE/DELETE auto-COMMITs.
     * Returns 1 (on) or 0 (off).
     */
    public function getAutocommit(): int
    {
        return (int) $this->pdo->query('SELECT @@autocommit')->fetchColumn();
    }

    /**
     * Video 2 (Bro Code): toggle AUTOCOMMIT for this session.
     * SET AUTOCOMMIT = 0 lets you group queries then COMMIT/ROLLBACK manually.
     * NOTE: PDO::beginTransaction() disables autocommit implicitly until commit().
     */
    public function setAutocommit(bool $on): void
    {
        $this->pdo->exec('SET AUTOCOMMIT = ' . ($on ? '1' : '0'));
    }

    /**
     * Video 1 (RuchiCodes): SAVEPOINT demo — partial rollback.
     *
     * Same 3 steps as payForRequest(), but with savepoints:
     *   BEGIN → INSERT payment → SAVEPOINT sp_payment_done
     *         → UPDATE request → SAVEPOINT sp_status_done
     *         → INSERT notification → COMMIT
     *
     * If the notify step fails, we do ROLLBACK TO sp_status_done
     * (keep payment + status, discard only the failed notify),
     * insert a fallback notification, then COMMIT.
     * Any earlier failure still does a full ROLLBACK.
     */
    public function payForRequestWithSavepoint(
        int $requestId,
        float $amount,
        string $method,
        int $actorId,
        bool $isStaff,
        bool $simulateNotifyFailure = false
    ): array {
        $allowedMethods = ['cash', 'gcash', 'maya', 'bank'];
        $method = strtolower(trim($method));

        try {
            if ($requestId <= 0) {
                throw new RuntimeException('Choose a valid request to pay for.');
            }
            if ($amount < 0) {
                throw new RuntimeException('Payment amount cannot be negative.');
            }
            if (!in_array($method, $allowedMethods, true)) {
                throw new RuntimeException('Choose a valid payment method.');
            }

            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare(
                'SELECT r.*, d.document_name, d.fee
                 FROM requests r
                 JOIN document_types d ON d.document_id = r.document_id
                 WHERE r.request_id = ? FOR UPDATE'
            );
            $stmt->execute([$requestId]);
            $request = $stmt->fetch();

            if (!$request) {
                throw new RuntimeException("Request #$requestId does not exist.");
            }
            if (!$isStaff && (int) $request['user_id'] !== $actorId) {
                throw new RuntimeException('You can only pay for your own requests.');
            }

            $check = $this->pdo->prepare('SELECT COUNT(*) FROM transactions WHERE request_id = ?');
            $check->execute([$requestId]);
            if ((int) $check->fetchColumn() > 0) {
                throw new RuntimeException("Request #$requestId is already paid.");
            }

            $fee = (float) $request['fee'];
            if ($amount < $fee) {
                throw new RuntimeException(
                    'Insufficient payment. The fee for ' . $request['document_name'] .
                    ' is ₱' . number_format($fee, 2) . '.'
                );
            }

            // 1) Record the payment.
            $insert = $this->pdo->prepare(
                'INSERT INTO transactions (amount_paid, payment_method, request_id) VALUES (?,?,?)'
            );
            $insert->execute([$amount, $method, $requestId]);
            $this->pdo->exec('SAVEPOINT sp_payment_done');

            // 2) Move the request forward.
            $update = $this->pdo->prepare(
                "UPDATE requests SET status = 'reviewing', staff_id = COALESCE(staff_id, ?) WHERE request_id = ?"
            );
            $update->execute([$isStaff ? $actorId : null, $requestId]);
            $this->pdo->exec('SAVEPOINT sp_status_done');

            // 3) Notify the owner. Simulate failure when asked (for demo).
            try {
                if ($simulateNotifyFailure) {
                    throw new RuntimeException('Simulated notify failure (demo).');
                }
                $notify = $this->pdo->prepare(
                    'INSERT INTO notifications (user_id, request_id, message) VALUES (?,?,?)'
                );
                $notify->execute([
                    (int) $request['user_id'],
                    $requestId,
                    'Payment of ₱' . number_format($amount, 2) . " ($method) received for request #$requestId.",
                ]);
            } catch (Throwable $notifyError) {
                // Partial rollback: keep payment + status, undo only the failed notify.
                $this->pdo->exec('ROLLBACK TO SAVEPOINT sp_status_done');
                $fallback = $this->pdo->prepare(
                    'INSERT INTO notifications (user_id, request_id, message) VALUES (?,?,?)'
                );
                $fallback->execute([
                    (int) $request['user_id'],
                    $requestId,
                    "Payment received for request #$requestId (recovered after notify error).",
                ]);
            }

            $this->pdo->exec('RELEASE SAVEPOINT sp_status_done');
            $this->pdo->exec('RELEASE SAVEPOINT sp_payment_done');
            $this->pdo->commit();

            return [
                'status' => 'success',
                'message' => '₱' . number_format($amount, 2) . " paid successfully for request #$requestId (savepoint flow).",
            ];
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }

            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }

    /**
     * List payments. Residents only see their own; staff see all.
     * Equivalent to the demo's getBalances().
     */
    public function getPayments(?int $userId = null, bool $staffView = false): array
    {
        $sql = 'SELECT t.*, r.purpose, r.status AS request_status, r.user_id,
                       d.document_name, d.fee, u.full_name
                FROM transactions t
                JOIN requests r ON r.request_id = t.request_id
                JOIN document_types d ON d.document_id = r.document_id
                JOIN users u ON u.user_id = r.user_id';
        $params = [];

        if (!$staffView && $userId !== null) {
            $sql .= ' WHERE r.user_id = :user_id';
            $params[':user_id'] = $userId;
        }

        $sql .= ' ORDER BY t.payment_date DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    /**
     * Requests that still need payment (no row in transactions yet).
     * Used to populate the pay-form dropdown.
     */
    public function getUnpaidRequests(?int $userId = null, bool $staffView = false): array
    {
        $sql = 'SELECT r.*, d.document_name, d.fee, u.full_name
                FROM requests r
                JOIN document_types d ON d.document_id = r.document_id
                JOIN users u ON u.user_id = r.user_id
                LEFT JOIN transactions t ON t.request_id = r.request_id
                WHERE t.transact_id IS NULL';
        $params = [];

        if (!$staffView && $userId !== null) {
            $sql .= ' AND r.user_id = :user_id';
            $params[':user_id'] = $userId;
        }

        $sql .= ' ORDER BY r.submission_date DESC';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll();
    }
}
