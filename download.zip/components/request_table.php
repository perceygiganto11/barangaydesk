<div class="table-card">
    <div class="table-wrap">
        <table>
            <thead><tr><th>REQUEST</th><?php if (is_staff()): ?><th>RESIDENT</th><?php endif; ?><th>SUBMITTED</th><th>EST. COMPLETION</th><th>STATUS</th><th>ACTION</th></tr></thead>
            <tbody>
            <?php if (!$requests): ?>
                <tr><td colspan="6"><div class="empty">No requests found. Start by browsing the document catalog.</div></td></tr>
            <?php else: foreach ($requests as $request): ?>
                <tr>
                    <td><strong>#<?= str_pad((string) $request['request_id'], 4, '0', STR_PAD_LEFT) ?></strong><small><?= e($request['document_name']) ?></small></td>
                    <?php if (is_staff()): ?><td><?= e($request['full_name']) ?></td><?php endif; ?>
                    <td><?= e(date('M j, Y', strtotime($request['submission_date']))) ?></td>
                    <td><?= e(date('M j, Y', strtotime($request['estimated_completion']))) ?></td>
                    <td><span class="status <?= e($request['status']) ?>"><?= e(ucfirst($request['status'])) ?></span></td>
                    <td>
                        <details class="request-actions">
                            <summary>Manage</summary>
                            <?php if (is_staff()): ?>
                                <form class="inline-form" method="post">
                                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_status"><input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                                    <select name="status" onchange="this.form.submit()"><option value="">Update status</option><?php foreach (['pending', 'reviewing', 'approved', 'rejected', 'released'] as $status): ?><option value="<?= $status ?>"><?= ucfirst($status) ?></option><?php endforeach; ?></select>
                                </form>
                            <?php endif; ?>
                            <?php if (!is_staff()): ?>
                                <form method="post">
                                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="update_request"><input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                                    <label>Purpose<textarea name="purpose" required><?= e($request['purpose']) ?></textarea></label>
                                    <button class="button small" type="submit">Save changes</button>
                                </form>
                                <details class="upload-details"><summary>Upload file</summary><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="upload_file"><input type="hidden" name="request_id" value="<?= $request['request_id'] ?>"><input type="file" name="document" accept=".pdf,.jpg,.jpeg,.png" required><button class="button small">Upload</button></form></details>
                            <?php endif; ?>
                            <form method="post" onsubmit="return confirm('Delete this request?');">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_request"><input type="hidden" name="request_id" value="<?= $request['request_id'] ?>"><button class="button small danger" type="submit">Delete request</button>
                            </form>
                        </details>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
