<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e(page_title($view)) ?> · BarangayDesk</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include __DIR__ . '/sidebar.php'; ?>
<main class="main">
    <header class="topbar">
        <div>
            <div class="eyebrow"><?= e(date('l, F j, Y')) ?></div>
            <h1><?= e(page_title($view)) ?></h1>
        </div>
        <div class="user-chip">
            <span class="avatar"><?= e(strtoupper(substr($current['full_name'], 0, 1))) ?></span>
            <span><strong><?= e($current['full_name']) ?></strong><small><?= e(ucfirst($current['user_type'])) ?></small></span>
        </div>
    </header>
    <section class="content">
        <?php foreach ($flashes as [$type, $msg]): ?>
            <div class="alert <?= e($type) ?>"><?= e($msg) ?></div>
        <?php endforeach; ?>
