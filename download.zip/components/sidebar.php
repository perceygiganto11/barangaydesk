<aside class="sidebar">
    <a class="brand" href="index.php"><span class="brand-mark">B</span><span>Barangay<span class="muted">Desk</span></span></a>
    <div class="eyebrow">Workspace</div>
    <nav>
        <a class="<?= $view === 'dashboard' ? 'active' : '' ?>" href="index.php">⌂ <span>Dashboard</span></a>
        <a class="<?= $view === 'catalog' ? 'active' : '' ?>" href="index.php?view=catalog">▤ <span>Document catalog</span></a>
        <a class="<?= $view === 'requests' ? 'active' : '' ?>" href="index.php?view=requests">◫ <span>My requests</span></a>
        <a class="<?= $view === 'transactions' ? 'active' : '' ?>" href="index.php?view=transactions">₱ <span>Payments</span></a>
        <a class="<?= $view === 'notifications' ? 'active' : '' ?>" href="index.php?view=notifications">◉ <span>Notifications</span></a>
        <a class="<?= $view === 'activity' ? 'active' : '' ?>" href="index.php?view=activity">◴ <span>Activity history</span></a>
    </nav>
    <div class="sidebar-bottom">
        <a href="index.php?view=profile">⚙ <span>Profile</span></a>
        <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="logout">
            <button>↪ <span>Sign out</span></button>
        </form>
    </div>
</aside>
