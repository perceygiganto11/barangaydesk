# OOP and CRUD Requirements

The project uses the `Request` class in `classes/Request.php` as its main entity.

| Requirement | Implementation |
|---|---|
| PHP classes and OOP principles | `final class Request` receives a `PDO` dependency through its constructor. |
| PDO prepared statements | All request CRUD and search operations use `$pdo->prepare()` with named parameters. |
| Insert | `addRequest()` inserts a new document request and returns its generated ID. |
| Fetch all | `getRequests()` fetches requests, with resident ownership filtering or a staff view. |
| Update | `updateRequest($id, $details)` updates only approved request fields. |
| Delete | `deleteRequest($id)` deletes one request by ID. |
| Search | `searchRequests($keyword)` searches purpose, status, document name, and resident name. |

The authenticated requests page exposes search, update, and delete controls for the user’s own requests. Staff can additionally update request status and manage any request. Request creation, fetching, searching, updates, and deletes are routed through the same entity class and persist through the PDO connection in `connection.php`.
