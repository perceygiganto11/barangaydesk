# ERD Review and Corrections

## Assessment

The submitted ERD contains seven intended entities: `users`, `requests`, `upload_file`, `transactions`, `notifications`, `documents_types`, and `activity_logs`. The original ZIP, however, implemented only a participant CRUD prototype and did not contain the document-request tables or workflows.

## Corrections

| Original issue | Correction in `database/schema.sql` | Reason |
|---|---|---|
| `documents_types` | `document_types` | Consistent singular table naming |
| `requirments` | `requirements` | Corrected spelling |
| `uploiad_at` | `uploaded_at` | Corrected spelling |
| `upload_file` | `uploaded_files` | Consistent plural resource naming |
| `requests.log_id` linked to `activity_logs.log_id` | Removed | A request does not own one activity log; activity logs belong to users and describe actions |
| Missing authentication data | Added `password_hash`, `created_at` to `users` | Required for secure registration and login |
| Missing workflow fields | Added `staff_id`, `notes` to `requests` | Required for staff assignment and review notes |
| Implicit key behavior | Added explicit primary keys, foreign keys, indexes through unique constraints, and delete behavior | Enforces data integrity |

The corrected schema preserves the core domain relationships: one user can submit many requests; one document type can be used by many requests; one request can have many uploaded files and notifications; one request has at most one transaction; and one user can generate many notifications and activity records.
