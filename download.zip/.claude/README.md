# Project Guidance

BarangayDesk is a PHP/MySQL application. Keep reusable UI fragments in `components/`, application bootstrap logic in `app/`, styling in `assets/`, and database files in `database/`.
