<?php

require_once __DIR__ . '/../connection.php';
require_once __DIR__ . '/../classes/Request.php';
require_once __DIR__ . '/../classes/Transaction.php';

// SQL Transactions demo — covers both videos:
//   Video 1 (RuchiCodes): COMMIT, ROLLBACK, SAVEPOINT with real examples.
//   Video 2 (Bro Code):   AUTOCOMMIT, COMMIT, ROLLBACK in MySQL.
//
// Barangay context: paying a document fee must atomically
// INSERT into `transactions` + UPDATE `requests` + INSERT into `notifications`.
// Any failure => ROLLBACK, walay ma-save nga partial.
$pdo = db();
$transaction = new Transaction($pdo);

// ── Video 2: AUTOCOMMIT ─────────────────────────────────────────────
// By default MySQL has AUTOCOMMIT=1: every INSERT/UPDATE/DELETE auto-COMMITs.
// Check it:
$autocommitDefault = $transaction->getAutocommit(); // expect 1
// $transaction->setAutocommit(false); // SET AUTOCOMMIT = 0 → manual COMMIT/ROLLBACK mode
// $transaction->setAutocommit(true);  // back to default

// Manual AUTOCOMMIT=0 block (Bro Code flow: group queries, then COMMIT or ROLLBACK):
// $pdo->exec('SET AUTOCOMMIT = 0');
// try {
//     $pdo->exec("INSERT INTO notifications (user_id, request_id, message) VALUES (1, NULL, 'autocommit demo')");
//     // $pdo->exec('COMMIT;');   // success → save permanently
//     $pdo->exec('ROLLBACK;');    // change mind / error → discard (demo discards)
// } finally {
//     $pdo->exec('SET AUTOCOMMIT = 1');
// }

// ── Video 1: COMMIT (happy path) ───────────────────────────────────
// BEGIN → INSERT payment → UPDATE request → INSERT notification → COMMIT.
$commitDemo = $transaction->payForRequest(
    requestId: 1,
    amount: 50.00,
    method: 'cash',
    actorId: 1,
    isStaff: false
);
// ["status" => "success"|"error", "message" => "..."]

// ── Video 1: ROLLBACK (error path) ──────────────────────────────────
// Kulang bayad / doble bayad / wrong request → exception → full ROLLBACK.
// Walay row ma-insert sa transactions, requests, or notifications.
$rollbackDemo = $transaction->payForRequest(
    requestId: 999999, // non-existent → triggers ROLLBACK
    amount: 10.00,
    method: 'gcash',
    actorId: 1,
    isStaff: false
);
// expect: ["status" => "error", "message" => "Request #999999 does not exist."]

// ── Video 1: SAVEPOINT (partial rollback) ───────────────────────────
// BEGIN → INSERT payment → SAVEPOINT sp_payment_done
//       → UPDATE request → SAVEPOINT sp_status_done
//       → INSERT notification (fails?) → ROLLBACK TO sp_status_done
//       → fallback notify → COMMIT.
// Payment + status are KEPT, only the failed step is undone.
$savepointDemo = $transaction->payForRequestWithSavepoint(
    requestId: 1,
    amount: 50.00,
    method: 'cash',
    actorId: 1,
    isStaff: false,
    simulateNotifyFailure: true // set false for normal flow
);

// ── Reads (like the demo's getBalances()) ───────────────────────────
$payments = $transaction->getPayments(1, false);
$unpaid = $transaction->getUnpaidRequests(1, false);

return [
    'autocommit_default' => $autocommitDefault,
    'commit_demo' => $commitDemo,
    'rollback_demo' => $rollbackDemo,
    'savepoint_demo' => $savepointDemo,
    'payments' => $payments,
    'unpaid' => $unpaid,
];
