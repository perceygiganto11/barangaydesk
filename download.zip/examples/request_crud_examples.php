<?php

require_once __DIR__ . '/../connection.php';
require_once __DIR__ . '/../classes/Request.php';

$request = new Request(db());

// 1. Adding a record.
$newId = $request->addRequest(
    'Proof of local residency',
    1,
    1,
    date('Y-m-d H:i:s', strtotime('+3 days'))
);

// 2. Fetching records in a list.
$allRequests = $request->getRequests(1);

// 3. Updating a record.
$request->updateRequest($newId, [
    'purpose' => 'Updated proof of local residency',
]);

// 4. Deleting a record.
$request->deleteRequest($newId);

// 5. Searching records.
$matches = $request->searchRequests('residency', 1);

return [
    'newId' => $newId,
    'allRequests' => $allRequests,
    'matches' => $matches,
];
